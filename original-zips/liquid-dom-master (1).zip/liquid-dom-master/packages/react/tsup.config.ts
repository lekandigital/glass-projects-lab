import { defineConfig } from 'tsup'

export default defineConfig({
  entry: {
    index: 'src/index.ts',
  },
  format: ['esm', 'cjs'],
  dts: true,
  clean: true,
  sourcemap: true,
  target: 'es2022',
  external: [
    '@liquid-dom/layout',
    '@liquid-dom/core',
    '@liquid-dom/core/layout',
    'react',
    'react-dom',
  ],
})
